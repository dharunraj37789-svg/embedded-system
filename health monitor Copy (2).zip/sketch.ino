#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

const int heartRatePin = A0;
const int buzzerPin = 8;

void setup() {
  Serial.begin(9600);

  pinMode(buzzerPin, OUTPUT);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Health Monitor");

  delay(1500);
  lcd.clear();
}

void loop() {
  int sensorValue = analogRead(heartRatePin);

  // Simulated heart rate: 50 to 130 BPM
  int bpm = map(sensorValue, 0, 1023, 50, 130);

  lcd.setCursor(0, 0);
  lcd.print("Heart: ");
  lcd.print(bpm);
  lcd.print(" BPM   ");

  Serial.print("Simulated Heart Rate: ");
  Serial.print(bpm);
  Serial.println(" BPM");

  // Educational demo threshold only
  if (bpm > 100) {
    digitalWrite(buzzerPin, HIGH);

    lcd.setCursor(0, 1);
    lcd.print("Check reading!  ");
  } else {
    digitalWrite(buzzerPin, LOW);

    lcd.setCursor(0, 1);
    lcd.print("Status: Demo OK ");
  }

  delay(500);
}